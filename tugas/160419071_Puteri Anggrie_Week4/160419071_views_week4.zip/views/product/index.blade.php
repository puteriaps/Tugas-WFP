<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>List Medicines</h2>           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Generic Name</th>
        <th>Medicines Form</th>
        <th>Restriction Formula</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
        @foreach($queryBuilder as $qb)
        <tr>
            <td>{{ $qb -> generic_name}}</td>
            <td>{{ $qb -> medicines_form}}</td>
            <td>{{ $qb -> restriction_formula}}</td>
            <td>{{ $qb -> description}}</td>
        </tr>
        @endforeach
    </tbody>
  </table>
</div>

</body>
</html> -->

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

   <!-- Styles -->
   <style>
   img{
     width: 250px;
     height: 150px;
    }
    </style>
</head>
<body>

<div class="container">
  <h2>List Medicines</h2>
  <br><br>
  
  <div class="row">
    @foreach($queryBuilder as $qb)
    <div class="col-md-4">
      <img src="{{ asset('images/'.$qb -> image)}}"/>
      <p>{{ $qb -> generic_name}} &nbsp; {{ $qb -> medicines_form}} &nbsp; {{ $qb -> price}}</p>
      <br><br>
    </div>
    @endforeach
  </div>
  
 
</div>

</body>
</html>

